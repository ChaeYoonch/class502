package Q3;

public class CoffeeMenu {
    public static final int StarBucksAmericano = 4000;
    public static final int StarBucksLatte = 4300;

    public static final int CoffeeBeanAmericano = 4100;
    public static final int CoffeeBeanLatte = 4500;
}